package com.Jose.sistemaingressos.ingressos.repository;

import com.Jose.sistemaingressos.ingressos.model.Ingresso;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IngressoRepository extends MongoRepository<Ingresso, String> {
    // O Spring Data já implementa save(), findById(), findAll() automaticamente!

    // NOVA BUSCA: Traz todos os ingressos comprados por um usuário específico
    List<Ingresso> findByUsuarioId(String usuarioId);
    List<Ingresso> findByEventoId(String eventoId);
    Optional<Ingresso> findByCodigoQr(String codigoQr);
    long countByEventoIdAndEstado(String eventoId, com.Jose.sistemaingressos.ingressos.model.EstadoIngresso estado);
}
