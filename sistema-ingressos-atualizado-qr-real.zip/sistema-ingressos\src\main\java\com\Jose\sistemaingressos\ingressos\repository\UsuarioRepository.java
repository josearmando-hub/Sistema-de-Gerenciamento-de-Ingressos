package com.Jose.sistemaingressos.ingressos.repository;

import com.Jose.sistemaingressos.ingressos.model.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends MongoRepository<Usuario, String> {
    // Método mágico do Spring: ele cria a busca no banco só pelo nome do método!
    Optional<Usuario> findByEmailAndSenha(String email, String senha);
    boolean existsByEmail(String email);
}