package com.Jose.sistemaingressos.ingressos.repository;

import com.Jose.sistemaingressos.ingressos.model.Reserva;
import com.Jose.sistemaingressos.ingressos.model.StatusReserva;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReservaRepository extends MongoRepository<Reserva, String> {
    List<Reserva> findByClienteIdOrderByDataReservaDesc(String clienteId);
    List<Reserva> findByEventoId(String eventoId);
    Optional<Reserva> findByIngressoId(String ingressoId);
    boolean existsByClienteIdAndEventoIdAndStatusIn(String clienteId, String eventoId, Collection<StatusReserva> status);
    long countByEventoIdAndStatus(String eventoId, StatusReserva status);
}
